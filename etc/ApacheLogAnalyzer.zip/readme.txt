○使い方
JavaSE8がインストールされていることを前提とします
まずApacheLogAnalyzer.jarをvarフォルダのある場所に置く  
その後以下のいずれかの方法でApacheLogAnalyzer.jarを実行する
・実行可能jarファイルとして実行する(環境が整っているならばダブルクリックで起動する)
・コマンドプロンプト(Windows),ターミナル(Mac, linux)にて
  ***
  cd varフォルダのある場所
  java -jar ApacheLogAnalyzer.jar
  ***
  と打てば実行できる

○環境
・JavaSE8

○テスト用varフォルダ
実行のテスト用にvarフォルダを同梱しています

○time zoneについて
入出力時に処理・表記される時刻は、日本標準時/JST GMT+9:00 に変換してあつかうこととした。

○クライアントの識別子と認証ユーザー名について
“,[,]は含まれないもののとする。