○使い方
JavaSE8がインストールされていることを前提とします
まずApacheLogAnalyzer.jarをvarフォルダのある場所に置く  
その後以下のいずれかの方法でApacheLogAnalyzer.jarを実行する
・実行可能jarファイルとして実行する(環境が整っているならばダブルクリックで起動する)
・コマンドプロンプト(Windows),ターミナル(Mac, linux)にて
  ***
  cd varフォルダのある場所
  java -jar ApacheLogAnalyzer.jar
  ***
  と打てば実行できる

○期間の指定
param.iniの1〜13行目の=の右辺の値を変えることで変更できる
各数値の対応は、
  beginYear	開始日時の年  beginMonth	開始日時の月  beginDay	開始日時の日付  beginHour	開始日時の時間  beginMinute	開始日時の分  beginSecond	開始日時の秒  endYear	終了日時の年  endinMonth	終了日時の月  endDay	終了日時の日付  endHour	終了日時の時間  endMinute	終了日時の分  endSecond	終了日時の秒


○logファイルの指定
param.iniの16行目以降の各行にファイル名を書き込んでいく
logファイルは全てvar/log/httpd/内にあるもののとする
例(var/log/httpd/access_logとvar/log/httpd/access_log2を読み込む場合):
  ***
  log file name:
  access_log
  access_log2
  ***

○環境
・JavaSE8

○テスト用varフォルダ
実行のテスト用にvarフォルダを同梱しています

○time zoneについて
入出力時に処理・表記される時刻は、日本標準時/JST GMT+9:00 に変換してあつかうこととした。

○クライアントの識別子と認証ユーザー名について
“,[,]は含まれないもののとする。
